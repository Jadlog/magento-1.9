<?php
$installer = $this;
$installer->startSetup();

$installer->addAttribute("order", "jad_log_embarcador_dfe", array("type"=>"varchar"));
$installer->endSetup();
